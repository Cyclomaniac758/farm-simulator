package animals;

public class Cow extends Animals {

  public Cow(){
    super.animalName = "Cow";
    super.buyPrice = 200;
    super.dailyEarnings = 80;
    super.happinessLevel = 100;
  }
}
