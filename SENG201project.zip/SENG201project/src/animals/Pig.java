package animals;

public class Pig extends Animals {

  public Pig() {
    super.animalName = "Pig";
    super.buyPrice = 120;
    super.dailyEarnings = 175;
    super.happinessLevel = 100;
  }
}
