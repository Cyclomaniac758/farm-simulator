package animals;

import java.util.ArrayList;

public abstract class Animals {

  protected String animalName;

  protected float buyPrice;

  protected float dailyEarnings;

  protected float happinessLevel;

  public String getanimalName() {
    return animalName;
  }

  public float getBuyPrice() {
    return buyPrice;
  }

  public float getDailyEarnings() {
    return dailyEarnings;
  }

  public float GethappinessLevel() {
    return happinessLevel;
  }

}