package animals;

public class Chicken extends Animals {

  public Chicken() {
    super.animalName = "Chicken";
    super.buyPrice = 40;
    super.dailyEarnings = 50;
    super.happinessLevel = 100;
  }
}
