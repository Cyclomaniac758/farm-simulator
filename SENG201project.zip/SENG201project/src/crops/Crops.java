package crops;

import java.util.ArrayList;

public abstract class Crops {

  protected String cropName;

  protected float buyPrice;

  protected float sellPrice;

  protected int growTime;

  public String getCropName() {
    return cropName;
  }

  public float getBuyPrice() {
    return buyPrice;
  }

  public float getSellPrice() {
    return sellPrice;
  }

  public int getGrowTime() {
    return growTime;
  }
}