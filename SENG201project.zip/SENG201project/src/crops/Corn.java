package crops;

public class Corn extends Crops {

  public Corn(){
    super.cropName = "Corn";
    super.buyPrice = 50;
    super.sellPrice = 80;
    super.growTime = 2;
  }
}
