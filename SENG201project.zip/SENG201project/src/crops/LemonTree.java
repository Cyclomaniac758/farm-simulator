package crops;

public class LemonTree extends Crops {

  public LemonTree() {
    super.cropName = "Lemon Tree";
    super.buyPrice = 175;
    super.sellPrice = 425;
    super.growTime = 3;
  }
}
