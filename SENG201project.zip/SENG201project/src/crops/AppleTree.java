package crops;

public class AppleTree extends Crops {

  public AppleTree() {
    super.cropName = "Apple Tree";
    super.buyPrice = 200;
    super.sellPrice = 500;
    super.growTime = 3;
  }
}
