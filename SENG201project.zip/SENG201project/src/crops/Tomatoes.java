package crops;

public class Tomatoes extends Crops {

  public Tomatoes() {
    super.cropName = "Tomatoes";
    super.buyPrice = 25;
    super.sellPrice = 40;
    super.growTime = 1;
  }
}
