package crops;

public class Wheat extends Crops {

  public Wheat(){
    super.cropName = "Wheat";
    super.buyPrice = 20;
    super.sellPrice = 25;
    super.growTime = 1;
  }
}
