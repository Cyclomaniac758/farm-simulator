package crops;

public class Carrots extends Crops {

  public Carrots(){
    super.cropName = "Carrots";
    super.buyPrice = 15;
    super.sellPrice = 20;
    super.growTime = 1;
  }
}