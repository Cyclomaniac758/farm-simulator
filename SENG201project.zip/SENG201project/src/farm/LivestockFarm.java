package farm;

import java.util.ArrayList;
import java.util.Arrays;

import crops.*;
import animals.*;

public class LivestockFarm extends Farm {

  public LivestockFarm(String name) {
    super.farmName = name;
    super.farmMoney = 2500;
    super.farmType = "Livestock";
    super.cropGrowingSpeed = 2;
    super.animalHappiness = 1.0f;
    super.cropList = new ArrayList<Crops>();
    super.animalList = new ArrayList<Animals>();
  }

}