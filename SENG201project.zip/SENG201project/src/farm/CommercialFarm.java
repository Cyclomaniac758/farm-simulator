package farm;

import java.util.ArrayList;
import java.util.Arrays;

import animals.*;
import crops.*;


public class CommercialFarm extends Farm {

  public CommercialFarm(String name) {
    super.farmName = name;
    super.farmMoney = 3000;
    super.farmType = "Commercial";
    super.cropGrowingSpeed = 3;
    super.animalHappiness = 0.5f;
    super.cropList = new ArrayList<Crops>();
    super.animalList = new ArrayList<Animals>();
  }

}
