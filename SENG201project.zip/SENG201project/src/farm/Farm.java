package farm;

import java.util.ArrayList;
import crops.*;
import animals.*;

/**
 * Farms are where the farmer does their tasks
 * @author Michael Peters
 *
 */
public abstract class Farm {

	/**
	 * The name of the farm
	 */
	protected String farmName;
	/**
  * The amount of money the farm starts with
  */
	protected float farmMoney;
  /**
	* The type of farm
  */
  protected String farmType;
	/**
	*The number of days it takes for a crop to grow on the farm
  */
	protected int cropGrowingSpeed;
  /**
  * The happiness of animals on the farm
  */
	protected float animalHappiness;


	/**
	 * The farmer this will replaced with the actual farmer class
	 */
	protected String farmer;

	/**
	 *
	 */

	protected ArrayList<Crops> cropList;


	protected ArrayList<Animals> animalList;

  /**
	* Gets farm Name
  * @return String farm name
  */
  public String getFarmName(){
    return farmName;
  }
  /**
  * Gets type of farm
  * @return The farms type
  */
  public String getFarmType(){
    return farmType;
  }

  public float getFarmMoney(){
    return farmMoney;
  }

  public int getGrowingSpeed(){
    return cropGrowingSpeed;
  }

  public float getAnimalHappiness(){
    return animalHappiness;
  }

  public String getFarmer(){
    return farmer;
  }
  
  public void printCropList() {
	  for (Crops crop : cropList) {
		  System.out.println(crop.getCropName());
	  }
  }
  
  public void printAnimalList() {
	  for (Animals animal : animalList) {
		  System.out.println(animal.getanimalName());
	  }
  }
  


	public String toString() {
		return String.format("the name of the farm is %s\nthe farmer is %s\nmoney count = $%s", getFarmName(), getFarmer(), getFarmMoney());
	}


	public static void main(String[] args) {
    OrchardFarm myNewFarm = new OrchardFarm("my orchard");
    System.out.println(myNewFarm.toString());
    myNewFarm.printAnimalList();
    myNewFarm.printCropList();

    FamilyFarm famtime = new FamilyFarm("Family time");
    System.out.println(famtime.toString());

    LivestockFarm lively = new LivestockFarm("cull season");
    System.out.println(lively.toString());

    CommercialFarm fonterra = new CommercialFarm("The scotts");
    System.out.println(fonterra.toString());

	}

}