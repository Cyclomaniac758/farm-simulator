package farm;

import java.util.ArrayList;
import java.util.Arrays;
import animals.*;
import crops.*;

public class FamilyFarm extends Farm {

  public FamilyFarm(String name) {
    super.farmName = name;
    super.farmMoney = 1500;
    super.farmType = "Family";
    super.cropGrowingSpeed = 2;
    super.animalHappiness = 1.5f;
    super.cropList = new ArrayList<Crops>();
    super.animalList = new ArrayList<Animals>();
  }

}
