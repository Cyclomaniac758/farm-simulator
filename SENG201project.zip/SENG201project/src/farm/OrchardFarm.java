package farm;

import java.util.ArrayList;
import java.util.Arrays;

import crops.*;
import animals.*;

public class OrchardFarm extends Farm {

	public OrchardFarm(String name) {
		super.farmName = name;
		super.farmMoney = 2000;
		super.farmType = "Orchard";
		super.cropGrowingSpeed = 1;
		super.animalHappiness = 1.0f;
		super.cropList = new ArrayList<Crops>(Arrays.asList(new AppleTree(), new Carrots(), new Corn(), new LemonTree(), new Tomatoes(), new Wheat()));
		super.animalList = new ArrayList<Animals>(Arrays.asList(new Chicken(), new Cow(), new Pig()));
	}


}
